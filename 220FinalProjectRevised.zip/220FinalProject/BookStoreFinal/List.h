//
// Created by Kristina Keenan on 11/28/16.
//

#ifndef BOOKSTOREFINAL_LIST_H
#define BOOKSTOREFINAL_LIST_H


class List{

public:

    //add book alphabetically
    virtual void add(Book* bookToAdd)= 0;

    virtual


private:







};





#endif //BOOKSTOREFINAL_LIST_H
